# Ex3-figures.R  --  Example 3 figure and table (Section 3.3)
# Produces Figure 3 (figures/elicit_fig.pdf) and prints Table 4.
# Loads results/Ex3-results.rds, re-simulates the p-values, and evaluates the
# optimised graph against the value-ordered, power-ordered, and Holm comparators.

source("00-shared-settings.R")
library(ggplot2)
library(ggraph)

res <- readRDS(file.path(RESULTS_DIR, "Ex3-results.rds"))
m   <- length(res$hyp_names)

p <- autoplot(res$opt_graph, digits = 3)
p$data$y[c(3, 5)] <- -1

# --- 1) Label nodes as H_1, ... with weight underneath ---
i <- as.integer(sub("^H", "", p$data$name))
tol <- 5e-4
wt_str <- ifelse(
  is.na(p$data$weight),
  "NA",
  ifelse(abs(p$data$weight) < tol, "0", sprintf("%.0f", p$data$weight))
)

p$data$label <- sprintf('atop(H[%d], "%s")', i, wt_str)

# --- 2) Remove existing node point + node text layers ---
is_point <- vapply(p$layers, \(L) inherits(L$geom, "GeomPoint"), logical(1))
is_text <- vapply(p$layers, \(L) inherits(L$geom, "GeomText"), logical(1))
p$layers <- p$layers[!(is_point | is_text)]

# --- 3) Add custom node points + parsed labels ---
p <- p +
  ggraph::geom_node_point(
    shape = 21, size = 30, stroke = 0.3,
    colour = "black", fill = NA, alpha = 1
  ) +
  ggraph::geom_node_text(
    aes(label = .data$label), parse = TRUE, size = 5
  )

cairo_pdf(
  file.path(FIGURES_DIR, "elicit_fig.pdf"),
  width = 8 * 0.8, height = 8 * 0.8, pointsize = 12
)
print(p)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "elicit_fig.pdf"))

# Re-simulate the p-values (same seed as Ex3-optimise.R) and rebuild the gain.
set.seed(202613)
pvals   <- simulate_pvalues(res$power_nominal, ALPHA, res$corr_matrix, nsim = NSIM_LOCAL)
gain_fn <- trial_success(!!res$gain_objective, verbose = FALSE)

# Comparators: value-ordered, power-ordered, and H1->H2->Holm{H3,H4,H5}.
value_seq <- make_fixed_sequence(seq_len(m),      res$hyp_names)
power_seq <- make_fixed_sequence(c(1, 2, 5, 3, 4), res$hyp_names)
holm_sec  <- list(
  hypotheses  = setNames(c(1, 0, 0, 0, 0), res$hyp_names),
  transitions = matrix(
    c(0, 1,   0,   0,   0,
      0, 0, 1/3, 1/3, 1/3,
      0, 0,   0, 0.5, 0.5,
      0, 0, 0.5,   0, 0.5,
      0, 0, 0.5, 0.5,   0),
    nrow = m, byrow = TRUE, dimnames = list(res$hyp_names, res$hyp_names)
  )
)

eval_graph <- function(g) calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = g$hypotheses, trans_matrix = g$transitions,
  custom_power = list(gain = gain_fn), sum_to_one_constraint = FALSE
)

opt_power   <- calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = res$opt_graph$hyp_weight, trans_matrix = res$opt_graph$trans_matrix,
  custom_power = list(gain = gain_fn), sum_to_one_constraint = FALSE
)
value_power <- eval_graph(value_seq)
power_power <- eval_graph(power_seq)
holm_power  <- eval_graph(holm_sec)

make_row <- function(label, p) data.frame(
  Procedure    = label,
  ExpectedGain = round(p$gain, 3),
  H3_Pruritus  = round(p$local_power[3], 3),
  H4_DLQI      = round(p$local_power[4], 3),
  H5_SCORAD    = round(p$local_power[5], 3),
  row.names    = NULL
)

tab <- rbind(
  make_row("Optimised graph",        opt_power),
  make_row("Value-ordered sequence", value_power),
  make_row("Power-ordered sequence", power_power),
  make_row("H1->H2->Holm{H3,H4,H5}", holm_power)
)

cat("\n===== Example 3 -- Table 4 =====\n")
print(tab, row.names = FALSE)

write.csv(tab, file.path(RESULTS_DIR, "Ex3-table4.csv"), row.names = FALSE)
