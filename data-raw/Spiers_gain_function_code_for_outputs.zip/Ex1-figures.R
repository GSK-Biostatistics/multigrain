# Ex1-figures.R  --  Example 1 figure and table (Section 3.1)
# Produces Figure 1 (figures/subgroup_fig.pdf) and prints Table 2.
# Loads results/Ex1-results.rds, re-simulates the p-values, and evaluates the
# optimised graph against the fixed-sequence and Holm comparators.

source("00-shared-settings.R")
library(ggplot2)
library(ggraph)

res <- readRDS(file.path(RESULTS_DIR, "Ex1-results.rds"))

p <- autoplot(res$opt_graph, digits = 3)

# --- 1) Create plotmath labels: atop(H["E,1"], "0.451") ---
# Node names are "H_E1", "H_E2", ..., "H_T3"; extract group and index.
grp <- sub("^H_(.).*", "\\1", p$data$name)
k   <- as.integer(sub("^H_.", "", p$data$name))

tol <- 5e-4
wt_str <- ifelse(
  is.na(p$data$weight),
  "NA",
  ifelse(abs(p$data$weight) < tol, "0", sprintf("%.3f", p$data$weight))
)

p$data$label <- sprintf('atop(H["%s,%d"], "%s")', grp, k, wt_str)

# --- 2) Remove existing node point + node text layers ---
is_point <- vapply(p$layers, \(L) inherits(L$geom, "GeomPoint"), logical(1))
is_text <- vapply(p$layers, \(L) inherits(L$geom, "GeomText"), logical(1))
p$layers <- p$layers[!(is_point | is_text)]

# --- 3) Add custom node points + parsed labels ---
p <- p +
  ggraph::geom_node_point(
    shape = 21, size = 30, stroke = 0.3,
    colour = "black", fill = NA, alpha = 1
  ) +
  ggraph::geom_node_text(
    aes(label = .data$label), parse = TRUE, size = 5
  )

cairo_pdf(
  file.path(FIGURES_DIR, "subgroup_fig.pdf"),
  width = 8 * 1.1, height = 5.811 * 1.1, pointsize = 12
)
print(p)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "subgroup_fig.pdf"))

# Re-simulate the p-values (new seed)
set.seed(202611)
pvals   <- simulate_pvalues(res$power_nominal, ALPHA, res$corr_matrix, nsim = NSIM_LOCAL)
gain_fn <- trial_success(!!res$gain_objective, verbose = FALSE)

# Comparators: fixed sequence (descending nominal power) and Holm-Bonferroni.
fs   <- make_fixed_sequence(res$fs_order, res$hyp_names)
holm <- make_bonferroni_holm(length(res$hyp_names), res$hyp_names)

opt_power <- calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = res$opt_graph$hyp_weight, trans_matrix = res$opt_graph$trans_matrix,
  custom_power = list(gain = gain_fn)
)
fs_power <- calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = fs$hypotheses, trans_matrix = fs$transitions,
  custom_power = list(gain = gain_fn), sum_to_one_constraint = FALSE
)
holm_power <- calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = holm$hypotheses, trans_matrix = holm$transitions,
  custom_power = list(gain = gain_fn)
)

make_row <- function(label, p) {
  data.frame(
    Procedure    = label,
    ExpectedGain = round(p$gain, 3),
    t(round(p$local_power, 3)),
    check.names  = FALSE
  )
}

tab <- rbind(
  make_row("Optimised graph", opt_power),
  make_row("Fixed sequence",  fs_power),
  make_row("Holm-Bonferroni", holm_power)
)
names(tab)[3:8] <- res$hyp_names

cat("\n===== Example 1 -- Table 2 =====\n")
print(tab, row.names = FALSE)

write.csv(tab, file.path(RESULTS_DIR, "Ex1-table2.csv"), row.names = FALSE)
