# Ex1-optimise.R  --  Example 1: Subgroup trial (Section 3.1)
# m = 6 hypotheses: enriched (E) and total (T) populations, each with one
# primary and two key secondary endpoints, ordered (H_E1, H_E2, H_E3, H_T1, H_T2, H_T3).
# Saves results to results/Ex1-results.rds. Intended for HPC (hours).

source("00-shared-settings.R")
set.seed(202601)

HYP_NAMES <- c("H_E1", "H_E2", "H_E3", "H_T1", "H_T2", "H_T3")
m <- 6L

power_nominal <- c(0.90, 0.90, 0.86, 0.88, 0.88, 0.84)

# Compound symmetry rho = 0.4 within each population; Corr(Z_{E,j}, Z_{T,j}) = sqrt(2/5);
# cross-population cross-endpoint = rho * sqrt(2/5).
rho_within <- 0.5
fr <- sqrt(2 / 5)
pop <- c("E", "E", "E", "T", "T", "T")
endp <- c(1, 2, 3, 1, 2, 3)

corr_matrix <- diag(m)
for (i in seq_len(m)) {
  for (j in seq_len(m)) {
    if (i == j) {
      next
    }
    corr_matrix[i, j] <- if (pop[i] == pop[j]) {
      rho_within
    } else if (endp[i] == endp[j]) {
      fr
    } else {
      rho_within * fr
    }
  }
}
dimnames(corr_matrix) <- list(HYP_NAMES, HYP_NAMES)
stopifnot(isSymmetric(corr_matrix), all(eigen(corr_matrix)$values > 0))

# psi(r) = r_{T1}(4 + r_{T2} + r_{T3}) + r_{E1}(3 + 0.75 r_{E2} + 0.75 r_{E3}), max = 10.5
gain_fn <- trial_success(
  (1 / 10.5) * (r4 * (4 + r5 + r6) + r1 * (3 + 0.75 * r2 + 0.75 * r3))
)

subgroup_constr <- graph_constraint(
  hyp_constraint = c(NA, 0, 0, NA, 0, 0),
  trans_constraint = matrix(
    c(
      #  E1   E2   E3   T1   T2   T3
         0,   NA,  NA,  NA,   0,   0,  # E1 -> E2, E3, T1
         0,    0,  NA,  NA,   0,   0,  # E2 -> E3, T1
         0,   NA,   0,  NA,   0,   0,  # E3 -> E2, T1
        NA,    0,   0,   0,  NA,  NA,  # T1 -> E1, T2, T3
        NA,    0,   0,   0,   0,  NA,  # T2 -> E1, T3
        NA,    0,   0,   0,  NA,   0   # T3 -> E1, T2
    ),
    nrow = m,
    byrow = TRUE
  ),
  names = HYP_NAMES
)

pvals <- simulate_pvalues(
  power_nominal = power_nominal,
  alpha = ALPHA,
  corr_matrix = corr_matrix,
  nsim = NSIM_LOCAL
)

opt_graph <- graph_optimise(
  pvals = pvals,
  graph_constraint = subgroup_constr,
  trial_success = gain_fn,
  alpha = ALPHA,
  control = SHARED_CONTROL,
  num_threads = NUM_THREADS,
  verbose = TRUE
)

# Fixed-sequence comparator order (descending nominal power), stored for the
# figure script. Comparators and their evaluation are built in Ex1-figures.R.
fs_order <- c(1, 2, 4, 5, 3, 6)

results <- list(
  example = 1L,
  hyp_names = HYP_NAMES,
  power_nominal = power_nominal,
  corr_matrix = corr_matrix,
  constraint = subgroup_constr,
  gain_objective = gain_fn$objective,
  fs_order = fs_order,
  opt_graph = opt_graph
)
saveRDS(results, file.path(RESULTS_DIR, "Ex1-results.rds"))

cat("\nExample 1 -- optimisation complete; results saved to Ex1-results.rds\n")
cat("Run Ex1-figures.R to produce the figure and Table 2.\n")
