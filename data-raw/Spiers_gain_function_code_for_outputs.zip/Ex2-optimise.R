# Ex2-optimise.R  --  Example 2: Sample-size optimisation (FIBRONEER-ILD, Section 3.2)
# m = 4 hypotheses: H1 High/primary, H2 High/secondary, H3 Low/primary, H4 Low/secondary.
# Finds the minimum per-arm n such that some valid graph achieves expected gain >= 0.85.
# Saves results to results/Ex2-results.rds. Intended for HPC (hours).

source("00-shared-settings.R")
set.seed(202602)

HYP_NAMES <- c("H1_FVC_High", "H2_Comp_High", "H3_FVC_Low", "H4_Comp_Low")
m <- 4L
N_ARMS <- 3L
TARGET_GAIN <- 0.85

delta <- c(0.250, 0.150, 0.230, 0.145)

corr_matrix <- matrix(
  c(
    1.0,
    0.4,
    0.5,
    0.2,
    0.4,
    1.0,
    0.2,
    0.5,
    0.5,
    0.2,
    1.0,
    0.4,
    0.2,
    0.5,
    0.4,
    1.0
  ),
  nrow = m,
  byrow = TRUE,
  dimnames = list(HYP_NAMES, HYP_NAMES)
)
stopifnot(isSymmetric(corr_matrix), all(eigen(corr_matrix)$values > 0))

# psi(r) = I{r1*r2 + r3*r4 >= 1}: dual-endpoint success for at least one dose.
dual_success <- trial_success((r1 && r2) || (r3 && r4))
constr <- graph_constraint(
  hyp_constraint = c(NA, 0, NA, 0),
  trans_constraint = matrix(
    c(
      0,  NA, NA, NA, # H1 -> H2, H3, H4 free
      0,   0, NA, NA, # H2 -> H1 forbidden; H2 -> H3, H4 free
      NA, NA,  0, NA, # H3 -> H1, H2 free; H3 -> H4 free
      NA, NA,  0,  0  # H4 -> H3 forbidden; H4 -> H1, H2 free
    ),
    nrow = m,
    byrow = TRUE
  ),
  names = HYP_NAMES
)

opt <- graph_optimise_n(
  graph_constraint = constr,
  effect_size = delta,
  trial_success = dual_success,
  target = TARGET_GAIN,
  alpha = ALPHA,
  sigma = corr_matrix,
  n_range = c(2L, 1000L),
  nsim = NSIM_LOCAL,
  num_threads = NUM_THREADS,
  control = SHARED_CONTROL,
  seed = 202602,
  verbose = TRUE
)

results <- list(
  example = 2L,
  hyp_names = HYP_NAMES,
  delta = delta,
  corr_matrix = corr_matrix,
  constraint = constr,
  gain_objective = dual_success$objective,
  target_gain = TARGET_GAIN,
  n_arms = N_ARMS,
  opt_graph = opt,
  opt_hyp_weight = opt$hyp_weight,
  opt_trans_matrix = opt$trans_matrix,
  opt_gain = opt$power$trial_success,
  n_star = opt$n_final
)

saveRDS(results, file.path(RESULTS_DIR, "Ex2-results.rds"))

cat("\nExample 2 -- optimisation complete; results saved to Ex2-results.rds\n")
cat(sprintf(
  "  Optimised graph : n = %d,  N_total = %d  (gain %.3f)\n",
  opt$n_final,
  N_ARMS * opt$n_final,
  opt$power$trial_success
))
cat("Run Ex2-figures.R for the comparator sample sizes and figure.\n")
