# Ex3-optimise.R  --  Example 3: Elicitation of incremental gain (tralokinumab, Section 3.3)
# m = 5 hypotheses: H1 IGA (co-primary), H2 EASI-75 (co-primary),
#                   H3 Pruritus, H4 DLQI, H5 SCORAD (key secondary).
# Saves results to results/Ex3-results.rds. Intended for HPC (hours).

source("./submission/00-shared-settings.R")
set.seed(202603)

HYP_NAMES <- c("H1_IGA", "H2_EASI", "H3_Pruritus", "H4_DLQI", "H5_SCORAD")
m <- 5L

power_nominal <- c(0.90, 0.90, 0.80, 0.70, 0.85)

corr_matrix <- matrix(
  c(1.0, 0.8, 0.5, 0.5, 0.8,
    0.8, 1.0, 0.5, 0.5, 0.8,
    0.5, 0.5, 1.0, 0.5, 0.5,
    0.5, 0.5, 0.5, 1.0, 0.5,
    0.8, 0.8, 0.5, 0.5, 1.0),
  nrow = m, byrow = TRUE,
  dimnames = list(HYP_NAMES, HYP_NAMES)
)
stopifnot(isSymmetric(corr_matrix), all(eigen(corr_matrix)$values > 0))

# psi(r) = r1*r2*(0.556 + 0.252*r3 + 0.148*r4 + 0.044*r5)
# v_base = 1/(1+kappa) = 0.556; incremental weights from elicitation (kappa = 0.8).
gain_fn <- trial_success(
  r1 * r2 * (0.556 + 0.252 * r3 + 0.148 * r4 + 0.044 * r5)
)

elicit_constr <- graph_constraint(
  hyp_constraint = c(1, 0, 0, 0, 0),
  trans_constraint = matrix(
    c(0, 1,  0,  0,  0,
      0, 0, NA, NA, NA,
      0, 0,  0, NA, NA,
      0, 0, NA,  0, NA,
      0, 0, NA, NA,  0),
    nrow = m, byrow = TRUE
  ),
  names = HYP_NAMES
)

pvals <- simulate_pvalues(
  power_nominal = power_nominal,
  alpha         = ALPHA,
  corr_matrix   = corr_matrix,
  nsim          = NSIM_LOCAL
)

opt_graph <- graph_optimise(
  pvals            = pvals,
  graph_constraint = elicit_constr,
  trial_success    = gain_fn,
  alpha            = ALPHA,
  control          = SHARED_CONTROL,
  num_threads      = NUM_THREADS,
  verbose          = TRUE
)

results <- list(
  example        = 3L,
  hyp_names      = HYP_NAMES,
  power_nominal  = power_nominal,
  corr_matrix    = corr_matrix,
  constraint     = elicit_constr,
  gain_objective = gain_fn$objective,
  opt_graph      = opt_graph
)
saveRDS(results, file.path(RESULTS_DIR, "Ex3-results.rds"))

cat("\nExample 3 -- optimisation complete; results saved to Ex3-results.rds\n")
cat("Run Ex3-figures.R to produce the figure and Table 4.\n")
