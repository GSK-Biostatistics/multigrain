# 00-shared-settings.R
# Shared constants and helpers for all examples.

library(multigrain)

ALPHA <- 0.025

NSIM_GLOBAL <- 1e6 # GA phase
NSIM_LOCAL <- 5e6 # local search and evaluation

NUM_THREADS <- 60

SHARED_CONTROL <- multigrain_control() |>
  control_nsim_global(NSIM_GLOBAL) |>
  control_nsim_local(NSIM_LOCAL) |>
  control_global(run = 1000, pmutation = 1, pcrossover = 0, elitism = 1) |>
  control_local(xtol_rel = 5e-8)

RESULTS_DIR <- file.path("./submission/results")
FIGURES_DIR <- file.path("./submission/figures")
dir.create(RESULTS_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(FIGURES_DIR, showWarnings = FALSE, recursive = TRUE)

# --- Comparator graphs --- #
make_fixed_sequence <- function(order, names) {
  m <- length(order)
  hypotheses <- setNames(rep(0, m), names)
  hypotheses[order[1]] <- 1
  transitions <- matrix(0, m, m, dimnames = list(names, names))
  for (k in seq_len(m - 1)) {
    transitions[order[k], order[k + 1]] <- 1
  }
  list(hypotheses = hypotheses, transitions = transitions)
}

make_bonferroni_holm <- function(m, names) {
  hypotheses <- setNames(rep(1 / m, m), names)
  transitions <- matrix(1 / (m - 1), m, m, dimnames = list(names, names))
  diag(transitions) <- 0
  list(hypotheses = hypotheses, transitions = transitions)
}
