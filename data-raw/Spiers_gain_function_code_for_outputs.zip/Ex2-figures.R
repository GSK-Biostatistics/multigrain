# Ex2-figures.R  --  Example 2 figure and sample-size table (Section 3.2)
# Produces Figure 2 (figures/sample_size_fig.pdf) and the sample-size table.
# Loads results/Ex2-results.rds and computes the comparator sample sizes by
# bisection (fixed sequence, Holm) on common-random-number p-values.

source("00-shared-settings.R")
library(ggplot2)
library(ggraph)
library(mvtnorm)

res <- readRDS(file.path(RESULTS_DIR, "Ex2-results.rds"))
m   <- length(res$hyp_names)

p <- autoplot(res$opt_graph, digits = 3)
p$data$name <- c("H1", "H2", "H3", "H4")

# --- 1) Label nodes as H_1, ... with weight underneath (3 dps) ---
i <- as.integer(sub("^H", "", p$data$name))
tol <- 5e-4
wt_str <- ifelse(
  is.na(p$data$weight),
  "NA",
  ifelse(abs(p$data$weight) < tol, "0", sprintf("%.3f", p$data$weight))
)

p$data$label <- sprintf('atop(H[%d], "%s")', i, wt_str)

# --- 2) Remove existing node point + node text layers ---
is_point <- vapply(p$layers, \(L) inherits(L$geom, "GeomPoint"), logical(1))
is_text <- vapply(p$layers, \(L) inherits(L$geom, "GeomText"), logical(1))
p$layers <- p$layers[!(is_point | is_text)]

# --- 3) Add custom node points + parsed labels ---
p <- p +
  ggraph::geom_node_point(
    shape = 21, size = 30, stroke = 0.3,
    colour = "black", fill = NA, alpha = 1
  ) +
  ggraph::geom_node_text(
    aes(label = .data$label), parse = TRUE, size = 5
  )

cairo_pdf(
  file.path(FIGURES_DIR, "sample_size_fig.pdf"),
  width = 8 * 0.8, height = 5.811 * 0.8, pointsize = 12
)
print(p)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "sample_size_fig.pdf"))

# Minimum per-arm n for the comparator graphs. delta * sqrt(n) is the
# noncentrality at sample size n; z_null are shared standard-normal draws.
set.seed(202612)
gain_fn <- trial_success(!!res$gain_objective, verbose = FALSE)
z_null  <- rmvnorm(NSIM_LOCAL, mean = rep(0, m), sigma = res$corr_matrix)

gain_at_n <- function(n, graph, sum_to_one) {
  p <- stats::pnorm(sweep(z_null, 2, res$delta * sqrt(n), "+"), lower.tail = FALSE)
  calc_power_pvals(
    p, alpha = ALPHA,
    hyp_weight = graph$hypotheses, trans_matrix = graph$transitions,
    custom_power = list(gain = gain_fn), sum_to_one_constraint = sum_to_one
  )$gain
}

min_n <- function(graph, sum_to_one, target = res$target_gain, lo = 2L, hi = 1000L) {
  while (gain_at_n(hi, graph, sum_to_one) < target) {
    hi <- hi * 2L
    if (hi > 1e6) stop("No feasible n below 1e6 for this graph.")
  }
  while (lo < hi) {
    mid <- (lo + hi) %/% 2L
    if (gain_at_n(mid, graph, sum_to_one) >= target) {
      hi <- mid
    } else {
      lo <- mid + 1L
    }
  }
  lo
}

fs   <- make_fixed_sequence(seq_len(m), res$hyp_names)
holm <- make_bonferroni_holm(m, res$hyp_names)

n_fixed <- min_n(fs,   sum_to_one = FALSE)
n_holm  <- min_n(holm, sum_to_one = TRUE)

n_per_arm <- c(optimised = res$n_star, fixed_sequence = n_fixed, holm = n_holm)

tab <- data.frame(
  Procedure = c("Optimised graph", "Fixed sequence", "Holm-Bonferroni"),
  n_per_arm = n_per_arm,
  N_total   = res$n_arms * n_per_arm,
  row.names = NULL
)
cat("\n===== Example 2 -- minimum sample size for expected gain >=", res$target_gain, "=====\n")
print(tab, row.names = FALSE)

write.csv(tab, file.path(RESULTS_DIR, "Ex2-samplesize.csv"), row.names = FALSE)
