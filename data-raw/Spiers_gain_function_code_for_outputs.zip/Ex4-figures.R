# Ex4-figures.R  --  Example 4 figures and table (Section 3.4)
# Produces Figure 4a (figures/bayes_fig.pdf) and Figure 4b (figures/tau_sensitivity_fig.pdf),
# and prints Table 5. Loads results/Ex4-results.rds and re-simulates the two
# scenarios (fixed alternative and sigma_Delta = 0.8 prior) to evaluate Table 5.

source("00-shared-settings.R")
library(ggplot2)
library(ggraph)

res <- readRDS(file.path(RESULTS_DIR, "Ex4-results.rds"))
m   <- length(res$hyp_names)

p <- autoplot(res$opt_bayes, digits = 3)
p$data$x <- c(0, 0, -1, 1)
p$data$y <- c(1, 0, -1, -1)

# --- 1) Label nodes as H_1, ... with weight underneath ---
i <- as.integer(sub("^H", "", p$data$name))
tol <- 5e-4
wt_str <- ifelse(
  is.na(p$data$weight),
  "NA",
  ifelse(abs(p$data$weight) < tol, "0", sprintf("%.0f", p$data$weight))
)

p$data$label <- sprintf('atop(H[%d], "%s")', i, wt_str)

# --- 2) Remove existing node point + node text layers ---
is_point <- vapply(p$layers, \(L) inherits(L$geom, "GeomPoint"), logical(1))
is_text <- vapply(p$layers, \(L) inherits(L$geom, "GeomText"), logical(1))
p$layers <- p$layers[!(is_point | is_text)]

# --- 3) Add custom node points + parsed labels ---
p <- p +
  ggraph::geom_node_point(
    shape = 21, size = 30, stroke = 0.3,
    colour = "black", fill = NA, alpha = 1
  ) +
  ggraph::geom_node_text(
    aes(label = .data$label), parse = TRUE, size = 5
  )

cairo_pdf(
  file.path(FIGURES_DIR, "bayes_fig.pdf"),
  width = 8 * 0.8, height = 8 * 0.8, pointsize = 12
)
print(p)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "bayes_fig.pdf"))

# Table 5: evaluate the fixed sequence and the Bayes-optimal graph under both the
# fixed alternative and the sigma_Delta = 0.8 predictive prior.
predictive_pvals <- function(sigma_sec, nsim) {
  tau_vec <- c(res$sigma_primary, sigma_sec, sigma_sec, sigma_sec)
  eta   <- matrix(rnorm(nsim * m), nsim, m)
  eps   <- matrix(rnorm(nsim * m), nsim, m)
  Delta <- sweep(eta, 2, tau_vec, `*`) + rep(res$mu_ncp, each = nsim)
  Z     <- Delta + eps %*% chol(res$corr_matrix)
  stats::pnorm(Z, lower.tail = FALSE)
}

set.seed(202614)
gain_fn     <- trial_success(!!res$gain_objective, verbose = FALSE)
pvals_fixed <- simulate_pvalues(res$power_nominal, ALPHA, res$corr_matrix, nsim = NSIM_LOCAL)
pvals_bayes <- predictive_pvals(res$sigma_main, nsim = NSIM_LOCAL)

fixed_seq <- make_fixed_sequence(seq_len(m), res$hyp_names)

eval_under <- function(hyp_weight, trans_matrix, pvals) calc_power_pvals(
  pvals, alpha = ALPHA,
  hyp_weight = hyp_weight, trans_matrix = trans_matrix,
  custom_power = list(gain = gain_fn), sum_to_one_constraint = FALSE
)$gain

table5 <- data.frame(
  Scenario       = c("Fixed alternative (theta_0)", "Bayes prior (sigma_Delta = 0.8)"),
  Fixed_sequence = c(eval_under(fixed_seq$hypotheses, fixed_seq$transitions, pvals_fixed),
                     eval_under(fixed_seq$hypotheses, fixed_seq$transitions, pvals_bayes)),
  Bayes_optimal  = c(eval_under(res$opt_bayes$hyp_weight, res$opt_bayes$trans_matrix, pvals_fixed),
                     eval_under(res$opt_bayes$hyp_weight, res$opt_bayes$trans_matrix, pvals_bayes))
)

s <- res$sensitivity
df_long <- rbind(
  data.frame(sigma = s$sigma_Delta, edge = "g12", value = s$g12),
  data.frame(sigma = s$sigma_Delta, edge = "g13", value = s$g13),
  data.frame(sigma = s$sigma_Delta, edge = "g14", value = s$g14)
)

fig_b <- ggplot(df_long, aes(x = sigma, y = value, group = edge, linetype = edge)) +
  geom_smooth(method = "loess", span = 0.6, se = FALSE, linewidth = 1, colour = "black") +
  geom_vline(xintercept = res$sigma_main, linetype = 3) +
  scale_y_continuous(limits = c(0, 1)) +
  scale_linetype_discrete(
    labels = c(expression(g[12]), expression(g[13]), expression(g[14]))
  ) +
  labs(
    x        = expression(sigma[paste(Delta, ",", i)]),
    y        = expression(Transition ~ weight ~ from ~ H[1]),
    linetype = NULL
  ) +
  theme_bw(base_size = 12, base_family = "serif") +
  theme(
    legend.position   = "right",
    panel.grid.minor  = element_blank(),
    panel.grid.major  = element_blank(),
    axis.text         = element_text(colour = "black")
  )

cairo_pdf(file.path(FIGURES_DIR, "tau_sensitivity_fig.pdf"), width = 7, height = 5, pointsize = 10)
print(fig_b)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "tau_sensitivity_fig.pdf"))

cat("\n===== Example 4 -- Table 5 (gains scaled to [0,1]) =====\n")
print(format(table5, digits = 3), row.names = FALSE)

write.csv(table5, file.path(RESULTS_DIR, "Ex4-table5.csv"), row.names = FALSE)
write.csv(res$sensitivity, file.path(RESULTS_DIR, "Ex4-sensitivity.csv"), row.names = FALSE)
