# Ex4-optimise.R  --  Example 4: Bayes gain (Section 3.4)
# m = 4 hypotheses: H1 primary, H2-H4 key secondary.
# Produces: fixed-alternative optimum; Bayes-optimal graph at sigma_Delta = 0.8;
#           Table 5 (conditional vs Bayes gain); sensitivity sweep for Figure 4b.
# Saves results to results/Ex4-results.rds. Intended for HPC (hours).

source("00-shared-settings.R")
set.seed(202604)

HYP_NAMES <- c("H1", "H2", "H3", "H4")
m <- 4L

power_nominal <- c(0.90, 0.90, 0.80, 0.70)
mu_ncp        <- calc_ncp(power_nominal, alpha = ALPHA)   # (3.24, 3.24, 2.80, 2.48)

corr_matrix <- matrix(0.7, m, m); diag(corr_matrix) <- 1
dimnames(corr_matrix) <- list(HYP_NAMES, HYP_NAMES)

gain_fn <- trial_success(r1 * (0.4 + 0.2 * r2 + 0.2 * r3 + 0.2 * r4))

SIGMA_PRIMARY <- 0.2
SIGMA_MAIN    <- 0.8
SIGMA_GRID    <- seq(0, 1.5, by = 0.1)

# All weight on H1; secondaries recycle among themselves, not back to H1.
bayes_constr <- graph_constraint(
  hyp_constraint = c(1, 0, 0, 0),
  trans_constraint = matrix(
    c(0, NA, NA, NA,
      0,  0, NA, NA,
      0, NA,  0, NA,
      0, NA, NA,  0),
    nrow = m, byrow = TRUE
  ),
  names = HYP_NAMES
)

predictive_pvals <- function(sigma_sec, nsim, eta = NULL, eps = NULL) {
  tau_vec <- c(SIGMA_PRIMARY, sigma_sec, sigma_sec, sigma_sec)
  if (is.null(eta)) eta <- matrix(rnorm(nsim * m), nsim, m)
  if (is.null(eps)) eps <- matrix(rnorm(nsim * m), nsim, m)
  Delta <- sweep(eta, 2, tau_vec, `*`) + rep(mu_ncp, each = nsim)
  Z     <- Delta + eps %*% chol(corr_matrix)
  stats::pnorm(Z, lower.tail = FALSE)
}

# (1) Fixed-alternative optimum.
pvals_fixed <- simulate_pvalues(power_nominal, ALPHA, corr_matrix, nsim = NSIM_LOCAL)

opt_fixed_scenario <- graph_optimise(
  pvals            = pvals_fixed,
  graph_constraint = graph_constraint_free(m, names = HYP_NAMES),
  trial_success    = gain_fn,
  alpha            = ALPHA,
  control          = SHARED_CONTROL,
  num_threads      = NUM_THREADS,
  verbose          = TRUE
)

# (2) Bayes-optimal graph at sigma_Delta = 0.8.
pvals_bayes <- predictive_pvals(SIGMA_MAIN, nsim = NSIM_LOCAL)

opt_bayes <- graph_optimise(
  pvals            = pvals_bayes,
  graph_constraint = bayes_constr,
  trial_success    = gain_fn,
  alpha            = ALPHA,
  control          = SHARED_CONTROL,
  num_threads      = NUM_THREADS,
  verbose          = TRUE
)

results <- list(
  example            = 4L,
  hyp_names          = HYP_NAMES,
  power_nominal      = power_nominal,
  mu_ncp             = mu_ncp,
  corr_matrix        = corr_matrix,
  gain_objective     = gain_fn$objective,
  sigma_primary      = SIGMA_PRIMARY,
  sigma_main         = SIGMA_MAIN,
  bayes_constraint   = bayes_constr,
  opt_fixed_scenario = opt_fixed_scenario,
  opt_bayes          = opt_bayes,
  sensitivity        = NULL
)
saveRDS(results, file.path(RESULTS_DIR, "Ex4-results.rds"))

SWEEP_NSIM    <- 1e6
SWEEP_CONTROL <- multigrain_control() |>
  control_nsim_global(min(NSIM_GLOBAL, SWEEP_NSIM)) |>
  control_nsim_local(SWEEP_NSIM) |>
  control_global(run = 1000, pmutation = 1, pcrossover = 0, elitism = 1) |>
  control_local(xtol_rel = 5e-8)

set.seed(202604)
eta_crn <- matrix(rnorm(SWEEP_NSIM * m), SWEEP_NSIM, m)
eps_crn <- matrix(rnorm(SWEEP_NSIM * m), SWEEP_NSIM, m)

sweep_rows <- lapply(SIGMA_GRID, function(s) {
  message("Sensitivity sweep: sigma_Delta = ", s)
  pv  <- predictive_pvals(s, nsim = SWEEP_NSIM, eta = eta_crn, eps = eps_crn)
  fit <- graph_optimise(
    pvals = pv, graph_constraint = bayes_constr, trial_success = gain_fn,
    alpha = ALPHA, control = SWEEP_CONTROL, num_threads = NUM_THREADS, verbose = FALSE
  )
  G <- fit$trans_matrix
  data.frame(sigma_Delta = s, g12 = G[1, 2], g13 = G[1, 3], g14 = G[1, 4])
})
results$sensitivity <- do.call(rbind, sweep_rows)

saveRDS(results, file.path(RESULTS_DIR, "Ex4-results.rds"))

cat("\nExample 4 -- optimisation complete; results saved to Ex4-results.rds\n")
cat("Run Ex4-figures.R to produce Figures 4a/4b and Table 5.\n")
