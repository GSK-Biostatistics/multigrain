# Ex5-figures.R  --  Example 5 figures (Section 3.5)
# Produces Figure 5a (figures/two_node_graph_bw.pdf) and Figure 5b (figures/gsd_w1_wide.pdf).

source("00-shared-settings.R")
library(ggplot2)
library(igraph)
library(ggraph)
library(tibble)
library(scales)
library(grid)
library(ggtext)

# Figure 5a: two-node group sequential graph.
nodes <- tribble(
  ~name , ~x , ~y , ~label_math                          ,
  "H1"  , -1 ,  0 , 'atop(plain(H)[PFS], w[plain(PFS)])' ,
  "H2"  ,  1 ,  0 , 'atop(plain(H)[OS], w[plain(OS)])'
)
edges <- tribble(
  ~from , ~to , ~value , "H1" , "H2" , 1 , "H2" , "H1" , 1
)
g <- graph_from_data_frame(edges, vertices = nodes, directed = TRUE)
lay <- create_layout(g, layout = "manual", x = nodes$x, y = nodes$y)

fig_a <- ggraph(lay) +
  geom_edge_fan(
    aes(
      label = value,
      start_cap = circle(12, "mm"),
      end_cap = circle(12, "mm")
    ),
    arrow = arrow(type = "closed", length = unit(4, "mm")),
    strength = 1,
    colour = "black",
    linewidth = 0.35,
    angle_calc = "along",
    label_pos = 0.5,
    label_dodge = unit(3, "mm"),
    label_size = 4
  ) +
  geom_node_point(
    shape = 21,
    size = 30,
    stroke = 0.35,
    colour = "black",
    fill = "white"
  ) +
  geom_node_text(
    aes(label = label_math),
    parse = TRUE,
    size = 6,
    colour = "black",
    lineheight = 0.95
  ) +
  coord_equal(xlim = c(-1.35, 1.35), ylim = c(-0.70, 0.70), clip = "off") +
  theme_void() +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    panel.background = element_rect(fill = "white", colour = NA)
  )

cairo_pdf(
  file.path(FIGURES_DIR, "two_node_graph_bw.pdf"),
  width = 6.5,
  height = 3.0,
  pointsize = 12
)
print(fig_a)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "two_node_graph_bw.pdf"))

# Figure 5b: optimal w*_PFS sensitivity.
res <- readRDS(file.path(RESULTS_DIR, "Ex5-results.rds"))$w_star
res$lambda <- res$r
res$delta_f <- factor(res$delta, levels = sort(unique(res$delta)))

delta_levels <- levels(res$delta_f)
delta_labels <- paste0("delta==", format(as.numeric(delta_levels), trim = TRUE))
lambda_breaks <- sort(unique(res$lambda))
linetype_vals <- c("solid", "longdash", "dotdash")[seq_along(delta_levels)]
shape_vals <- c(16, 17, 15)[seq_along(delta_levels)]

fig_b <- ggplot(
  res,
  aes(x = lambda, y = w1_star, linetype = delta_f, shape = delta_f)
) +
  geom_line(linewidth = 0.9, colour = "black") +
  geom_point(size = 2.6, colour = "black", stroke = 0.35) +
  scale_x_log10(
    breaks = lambda_breaks,
    minor_breaks = NULL,
    labels = label_number(trim = TRUE)
  ) +
  scale_y_continuous(
    limits = c(0, 1),
    breaks = seq(0, 1, 0.25),
    expand = expansion(mult = c(0, 0.02))
  ) +
  scale_linetype_manual(
    values = linetype_vals,
    breaks = delta_levels,
    labels = parse(text = delta_labels),
    name = NULL
  ) +
  scale_shape_manual(
    values = shape_vals,
    breaks = delta_levels,
    labels = parse(text = delta_labels),
    name = NULL
  ) +
  labs(
    x = "OS-to-PFS value ratio (v<sub>OS</sub> / v<sub>PFS</sub>)",
    y = "Optimal hypothesis weight on PFS (w<sup>*</sup><sub>PFS</sub>)"
  ) +
  guides(
    linetype = guide_legend(
      nrow = 3,
      byrow = TRUE,
      override.aes = list(shape = NA, linewidth = 1.1),
      keywidth = unit(2.6, "cm")
    ),
    shape = "none"
  ) +
  theme_classic(base_size = 11) +
  theme(
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
    legend.position = c(0.98, 0.98),
    legend.justification = c(1, 1),
    legend.title = element_blank(),
    legend.text.align = 1,
    legend.key = element_blank(),
    legend.background = element_rect(
      fill = alpha("white", 0.85),
      colour = "black",
      linewidth = 0.3
    ),
    legend.margin = margin(3, 5, 3, 5),
    axis.text = element_text(colour = "black"),
    axis.title.x = element_markdown(margin = margin(t = 7), colour = "black"),
    axis.title.y = element_markdown(margin = margin(r = 7), colour = "black")
  )

cairo_pdf(
  file.path(FIGURES_DIR, "gsd_w1_wide.pdf"),
  width = 7,
  height = 4.5,
  pointsize = 10
)
print(fig_b)
dev.off()
message("Wrote ", file.path(FIGURES_DIR, "gsd_w1_wide.pdf"))

cat("\n===== Example 5 -- optimal w*_PFS =====\n")
print(res[, c("r", "delta", "w1_star", "Egain_star")], row.names = FALSE)